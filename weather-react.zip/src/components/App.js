import React from 'react';
import DayWeather from './weather/DayWeather'

function App() {

  return (
    <div className="App">
        <DayWeather/>
      </div>
   
   )
      
  }


export default App;
