import React, {Component} from 'react'
import './DayWeather.scss'
import Day from './Weather';
import axios from 'axios'
const KEY = 'b4aabba8f1adc8f5c62afc77071a2e28';
const URL = `http://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=${KEY}`;

//Presentation Logic -UI
class DayWeather extends Component{
    constructor(){
        super();
        this.state = {
            data: this.getWeatherData()
        }
    }

    getWeatherData(){
        axios.get(URL)
        .then(response =>{
            console.log(response);
        });
        return new Day("01-01-2019", "1.png",20);
    }

    // render = () =>(
    //     <div className="day--weather">
    //      <img src=""/>
    //      <h3>Thu ({this.state.data.date})</h3>
    //      <p>19 C</p>
    //     </div>
    render() {
        const {date,icon,temp} = this.state.data;
        return(
        <div className="day--weather">
         <img src={icon}/>
         <h3>Thu ({date})</h3>
         <p>{temp}</p>
        </div>
    )
    }
}
export default DayWeather