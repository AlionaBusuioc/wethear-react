//Business Logic
//Data Structures / exchange
// ... spread operator /destructuring
// import axios from 'axios'
// const KEY = ''
// const URL = ''

class Day{
    constructor(date, icon, temp){
        this.date = date;
        this.icon = icon;
        this.temp = temp;
    }
}
export default Day

//usage
//let d = new Day ("01-01-2050", "1.png", 20)